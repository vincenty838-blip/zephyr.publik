
import React, { useState, useRef, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { 
  GoogleGenAI, 
  Modality, 
  GenerateContentResponse,
  LiveServerMessage,
  Blob,
  Type
} from '@google/genai';
import { 
  ShoppingBag, 
  Sparkles, 
  MessageSquare, 
  Mic, 
  ChevronRight, 
  Zap, 
  Search,
  Wind,
  Droplets,
  Cpu,
  Star,
  Download,
  Key,
  Volume2,
  Image as ImageIcon,
  User,
  Lock, 
  Mail, 
  ArrowRight, 
  LogOut, 
  ArrowLeft, 
  Wallet, 
  Package, 
  X, 
  Camera, 
  Edit2, 
  Check, 
  ShieldCheck, 
  Plus, 
  Trash2, 
  Layers, 
  Link as LinkIcon, 
  Upload, 
  Info, 
  TrendingUp, 
  Save, 
  Eye, 
  AlertCircle, 
  ShoppingCart, 
  Minus, 
  Globe, 
  Share2, 
  Copy, 
  ExternalLink, 
  BarChart3, 
  SearchCode, 
  MessageSquareWarning, 
  Send, 
  Clock, 
  Filter, 
  MoreVertical, 
  CheckCircle2, 
  LayoutGrid, 
  ClipboardList, 
  NotebookPen, 
  History, 
  TrendingDown, 
  ArrowUpRight, 
  ArrowDownRight, 
  Coins,
  Banknote,
  CreditCard,
  ReceiptText,
  PackageCheck,
  QrCode
} from 'lucide-react';

// --- Types ---
type AppMode = 'store' | 'cart' | 'support' | 'admin' | 'google-sim' | 'wallet' | 'notes' | 'payment';
type AuthState = 'login' | 'register' | 'forgot-password';
type UserRole = 'user' | 'admin';
type AdminTab = 'inventory' | 'reports' | 'soldout';
type TransactionStatus = 'Menunggu Pembayaran' | 'Dibayar' | 'Selesai' | 'Dibatalkan';

interface Product {
  id: number;
  name: string;
  category: 'Device' | 'Freebase' | 'Saltnic' | 'Tools' | 'Atomizer';
  price: string;
  image: string;
  rating: number;
  description: string;
  totalSold: number;
  stock: number;
}

interface CartItem {
  product: Product;
  quantity: number;
}

interface UserReport {
  id: string;
  userName: string;
  userEmail: string;
  type: 'Kendala Teknis' | 'Saran Produk' | 'Masalah Pembayaran' | 'Lainnya';
  subject: string;
  message: string;
  timestamp: string;
  status: 'Baru' | 'Diproses' | 'Selesai';
  priority: 'Rendah' | 'Sedang' | 'Tinggi';
}

interface Transaction {
  id: string;
  userEmail: string;
  userName: string;
  items: { id: number; name: string; qty: number; price: string }[];
  totalPrice: number;
  status: TransactionStatus;
  date: string;
  paymentMethod: string;
}

interface AdminNote {
  id: string;
  title: string;
  content: string;
  date: string;
}

const DOMAIN_NAME = "vapestoreelite.com";

const INITIAL_PRODUCTS: Product[] = [
  { id: 1, name: "Midnight Haze", category: 'Freebase', price: "Rp 185.000", rating: 4.9, description: "Kombinasi sempurna antara sari buah blackberry hutan yang matang dengan sensasi menthol kristal yang memberikan kesegaran instan di setiap tarikan.", image: "https://images.unsplash.com/photo-1552332386-f8dd00dc2f85?auto=format&fit=crop&q=80&w=400", totalSold: 1240, stock: 45 },
  { id: 2, name: "Titan Mod V3", category: 'Device', price: "Rp 1.250.000", rating: 5.0, description: "Mod high-end dengan chipset tercanggih yang menjamin presisi output daya hingga 200W.", image: "https://images.unsplash.com/photo-1541600383005-565c949c2c7c?auto=format&fit=crop&q=80&w=400", totalSold: 850, stock: 5 },
  { id: 3, name: "Velvet Cloud", category: 'Saltnic', price: "Rp 145.000", rating: 4.8, description: "Sensasi lembut dari custard premium yang dipadukan dengan ekstrak vanila asli Madagaskar.", image: "https://images.unsplash.com/photo-1516062423079-7ca13cdc7f5a?auto=format&fit=crop&q=80&w=400", totalSold: 3100, stock: 88 },
  { id: 4, name: "Nano Pod Pro", category: 'Device', price: "Rp 450.000", rating: 4.7, description: "Pod sistem ultra-kompak dengan kontrol aliran udara (airflow) yang dapat disesuaikan.", image: "https://images.unsplash.com/photo-1574044536225-04753fd3e831?auto=format&fit=crop&q=80&w=400", totalSold: 2150, stock: 12 },
  { id: 5, name: "Gold Coil Series", category: 'Tools', price: "Rp 55.000", rating: 4.9, description: "Teknologi Mesh coil berlapis emas untuk konduktivitas panas yang lebih stabil.", image: "https://images.unsplash.com/photo-1614713568397-b31b779d0498?auto=format&fit=crop&q=80&w=400", totalSold: 5400, stock: 120 },
  { id: 6, name: "Dead Rabbit RTA", category: 'Atomizer', price: "Rp 380.000", rating: 4.6, description: "Atomizer dual coil legendaris yang mengutamakan produksi uap tebal tanpa mengorbankan detail rasa.", image: "https://images.unsplash.com/photo-1563203369-26f2e4a5ccf7?auto=format&fit=crop&q=80&w=400", totalSold: 1100, stock: 15 },
];

const VaporEliteApp = () => {
  const [inventory, setInventory] = useState<Product[]>(INITIAL_PRODUCTS);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<UserRole>('user');
  const [isAnimatingOut, setIsAnimatingOut] = useState(false);
  const [userProfile, setUserProfile] = useState({ 
    name: 'Elite Member', 
    email: 'guest@elite.com',
    avatar: '' as string | null
  });
  
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [editingProductId, setEditingProductId] = useState<number | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  
  const [reports, setReports] = useState<UserReport[]>([
    {
      id: 'REP-001',
      userName: 'Ahmad Faisal',
      userEmail: 'ahmad@example.com',
      type: 'Kendala Teknis',
      subject: 'Gagal Checkout',
      message: 'Saya tidak bisa menekan tombol checkout saat menggunakan metode pembayaran e-wallet.',
      timestamp: '2 jam yang lalu',
      status: 'Baru',
      priority: 'Tinggi'
    }
  ]);

  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [finances, setFinances] = useState({ income: 4500000, expenses: 1200000 });
  const [adminNotes, setAdminNotes] = useState<AdminNote[]>([
    { id: '1', title: 'Target Bulan Ini', content: 'Meningkatkan stok untuk liquid freebase karena permintaan tinggi.', date: '2024-05-20' }
  ]);
  const [noteForm, setNoteForm] = useState({ title: '', content: '' });
  const [financeEdit, setFinanceEdit] = useState<{ type: 'income' | 'expenses' | null, value: string }>({ type: null, value: '' });

  const [reportForm, setReportForm] = useState<Partial<UserReport>>({
    type: 'Kendala Teknis',
    subject: '',
    message: '',
    priority: 'Sedang'
  });

  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const productImageInputRef = useRef<HTMLInputElement>(null);
  
  const [showStats, setShowStats] = useState(false);
  
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '',
    category: 'Device',
    price: '',
    description: '',
    image: '',
    rating: 5.0,
    totalSold: 0,
    stock: 0
  });

  const [mode, setMode] = useState<AppMode>('store');
  const [adminTab, setAdminTab] = useState<AdminTab>('inventory');
  const [filter, setFilter] = useState<string>('Semua');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusMessage, setStatusMessage] = useState('');
  const [restockingId, setRestockingId] = useState<number | null>(null);
  const [confirmingTransactionId, setConfirmingTransactionId] = useState<string | null>(null);
  
  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAnimatingOut(true);
    setTimeout(() => {
      setIsLoggedIn(true);
      setIsAnimatingOut(false);
    }, 800);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserRole('user');
    setMode('store');
    setCart([]);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setUserProfile(prev => ({ ...prev, avatar: reader.result as string }));
      reader.readAsDataURL(file);
    }
  };

  const handleProductImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setNewProduct(prev => ({ ...prev, image: reader.result as string }));
      reader.readAsDataURL(file);
    }
  };

  const handleSaveName = () => {
    if (tempName.trim()) setUserProfile(prev => ({ ...prev, name: tempName }));
    setIsEditingName(false);
  };

  const startNameEdit = () => {
    setTempName(userProfile.name);
    setIsEditingName(true);
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.image) {
      setStatusMessage('Gagal: Gambar produk wajib ada.');
      return;
    }

    if (editingProductId) {
      setInventory(prev => prev.map(p => p.id === editingProductId ? { ...p, ...newProduct as Product } : p));
      setStatusMessage('Berhasil: Data & Stok produk telah diperbarui!');
      setEditingProductId(null);
    } else {
      const product: Product = { ...(newProduct as Product), id: Date.now() };
      setInventory(prev => [product, ...prev]);
      setStatusMessage('Berhasil: Produk baru telah ditambahkan!');
    }

    setNewProduct({ name: '', category: 'Device', price: '', description: '', image: '', rating: 5.0, totalSold: 0, stock: 0 });
    setTimeout(() => setStatusMessage(''), 3000);
  };

  const handleEditProduct = (product: Product) => {
    setEditingProductId(product.id);
    setNewProduct({ ...product });
    const formEl = document.getElementById('admin-form');
    if (formEl) formEl.scrollIntoView({ behavior: 'smooth' });
  };

  const handleDeleteProduct = (id: number) => setInventory(prev => prev.filter(p => p.id !== id));

  const handleAddToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        if (existing.quantity < product.stock) {
          return prev.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
        }
        setStatusMessage('Gagal: Melebihi stok yang tersedia.');
        return prev;
      }
      return [...prev, { product, quantity: 1 }];
    });
    setStatusMessage(`Berhasil: ${product.name} masuk ke keranjang.`);
    setSelectedProduct(null);
    setTimeout(() => setStatusMessage(''), 3000);
  };

  const updateCartQuantity = (productId: number, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.product.id === productId) {
        const newQty = item.quantity + delta;
        if (newQty > 0 && newQty <= item.product.stock) {
          return { ...item, quantity: newQty };
        }
      }
      return item;
    }));
  };

  const removeFromCart = (productId: number) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  // NEW: Payment System Flow
  const initiatePayment = () => {
    if (cart.length === 0) return;
    setMode('payment');
  };

  const handleProcessPayment = (method: string) => {
    const total = calculateTotal();
    const items = cart.map(c => ({ id: c.product.id, name: c.product.name, qty: c.quantity, price: c.product.price }));
    
    const newTransaction: Transaction = {
      id: `TRX-${Math.floor(Math.random() * 9000) + 1000}`,
      userEmail: userProfile.email,
      userName: userProfile.name,
      items,
      totalPrice: total,
      status: 'Dibayar', // Simulating user paid
      date: new Date().toLocaleString('id-ID'),
      paymentMethod: method
    };

    setTransactions(prev => [newTransaction, ...prev]);
    setCart([]);
    setStatusMessage('Pembayaran berhasil! Menunggu konfirmasi admin.');
    setTimeout(() => {
        setMode('store');
        setStatusMessage('');
    }, 3000);
  };

  const handleConfirmTransaction = (txId: string) => {
    setConfirmingTransactionId(txId);
    
    setTimeout(() => {
      const tx = transactions.find(t => t.id === txId);
      if (!tx) return;

      // Update Stock & TotalSold only after confirmation
      setInventory(prev => prev.map(p => {
        const item = tx.items.find(i => i.id === p.id);
        if (item) {
          return { ...p, stock: Math.max(0, p.stock - item.qty), totalSold: p.totalSold + item.qty };
        }
        return p;
      }));

      // Update Status to Selesai
      setTransactions(prev => prev.map(t => t.id === txId ? { ...t, status: 'Selesai' } : t));
      
      // Update Finances
      setFinances(prev => ({ ...prev, income: prev.income + tx.totalPrice }));

      setConfirmingTransactionId(null);
      setStatusMessage(`Transaksi ${txId} Berhasil Dikonfirmasi!`);
      setTimeout(() => setStatusMessage(''), 3000);
    }, 1500); // Visual duration for professional feel
  };

  const handleRestock = (productId: number) => {
    setRestockingId(productId);
    setTimeout(() => {
      setInventory(prev => prev.map(p => p.id === productId ? { ...p, stock: p.stock + 10 } : p));
      setRestockingId(null);
      setStatusMessage('Restok Berhasil! +10 Unit Ditambahkan.');
      setTimeout(() => setStatusMessage(''), 3000);
    }, 600);
  };

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteForm.title || !noteForm.content) return;
    const newNote: AdminNote = {
      id: Date.now().toString(),
      title: noteForm.title,
      content: noteForm.content,
      date: new Date().toLocaleDateString('id-ID')
    };
    setAdminNotes(prev => [newNote, ...prev]);
    setNoteForm({ title: '', content: '' });
    setStatusMessage('Catatan Tersimpan.');
    setTimeout(() => setStatusMessage(''), 3000);
  };

  const handleUpdateFinance = () => {
    const val = parseInt(financeEdit.value);
    if (isNaN(val)) return;
    if (financeEdit.type === 'income') {
      setFinances(prev => ({ ...prev, income: val }));
    } else if (financeEdit.type === 'expenses') {
      setFinances(prev => ({ ...prev, expenses: val }));
    }
    setFinanceEdit({ type: null, value: '' });
    setStatusMessage('Data Keuangan Diperbarui.');
    setTimeout(() => setStatusMessage(''), 3000);
  };

  const calculateTotal = () => {
    return cart.reduce((acc, item) => {
      const priceStr = item.product.price.replace(/[^\d]/g, '');
      const price = parseInt(priceStr);
      return acc + (price * item.quantity);
    }, 0);
  };

  const handleCopyLink = (product?: Product) => {
    const link = product 
      ? `https://${DOMAIN_NAME}/product/${product.id}`
      : `https://${DOMAIN_NAME}`;
    
    navigator.clipboard.writeText(link).then(() => {
      setStatusMessage('Tautan berhasil disalin!');
      setTimeout(() => setStatusMessage(''), 3000);
    });
  };

  const handleSubmitReport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportForm.subject || !reportForm.message) return;

    const newReport: UserReport = {
      id: `REP-${Math.floor(Math.random() * 900) + 100}`,
      userName: userProfile.name,
      userEmail: userProfile.email,
      type: reportForm.type as any,
      subject: reportForm.subject as string,
      message: reportForm.message as string,
      timestamp: 'Baru saja',
      status: 'Baru',
      priority: reportForm.priority as any
    };

    setReports(prev => [newReport, ...prev]);
    setReportForm({ type: 'Kendala Teknis', subject: '', message: '', priority: 'Sedang' });
    setStatusMessage('Laporan terkirim!');
    setTimeout(() => setStatusMessage(''), 3000);
  };

  const handleUpdateReportStatus = (id: string, newStatus: UserReport['status']) => {
    setReports(prev => prev.map(r => r.id === id ? { ...r, status: newStatus } : r));
    setStatusMessage(`Status ${id} diperbarui.`);
    setTimeout(() => setStatusMessage(''), 3000);
  };

  const filteredProducts = inventory.filter(p => {
    const matchesCategory = filter === 'Semua' || p.category === filter;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         p.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const totalSaldo = finances.income - finances.expenses;

  if (!isLoggedIn) {
    return (
      <div className={`fixed inset-0 z-[100] bg-[#050505] flex items-center justify-center overflow-hidden transition-all duration-700 ${isAnimatingOut ? 'opacity-0 scale-105 blur-lg' : 'opacity-100'}`}>
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-1/4 -left-1/4 w-[60%] h-[60%] bg-purple-600/10 blur-[120px] rounded-full"></div>
          <div className="absolute -bottom-1/4 -right-1/4 w-[60%] h-[60%] bg-indigo-600/10 blur-[120px] rounded-full"></div>
        </div>
        <div className="w-full max-w-md px-8 relative z-10">
          <div className="text-center mb-10"><div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center mx-auto mb-6"><Wind className="text-white w-10 h-10" /></div><h1 className="font-outfit font-black text-4xl tracking-tighter mb-2 bg-gradient-to-r from-white to-slate-500 bg-clip-text text-transparent">VAPOR ELITE</h1><p className="text-slate-500 text-sm font-medium">Portal Vaping Premium</p></div>
          <div className="flex bg-white/5 p-1 rounded-2xl mb-6 border border-white/10">
            <button onClick={() => setUserRole('user')} className={`flex-1 py-2 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${userRole === 'user' ? 'bg-white text-black' : 'text-slate-500'}`}>User</button>
            <button onClick={() => setUserRole('admin')} className={`flex-1 py-2 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${userRole === 'admin' ? 'bg-purple-600 text-white' : 'text-slate-500'}`}>Admin</button>
          </div>
          <div className="bg-[#0f0f0f]/80 backdrop-blur-3xl border border-white/5 p-8 rounded-[40px] shadow-2xl relative overflow-hidden">
            <form onSubmit={handleAuthSubmit} className="space-y-5">
              <div className="relative"><Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-600" /><input required type="email" placeholder="Email" className="w-full bg-white/[0.03] border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:border-purple-500" /></div>
              <div className="relative"><Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-600" /><input required type="password" placeholder="Password" className="w-full bg-white/[0.03] border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:border-purple-500" /></div>
              <button type="submit" className={`w-full py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl mt-4 active:scale-95 ${userRole === 'admin' ? 'bg-purple-600 text-white' : 'bg-white text-black'}`}>Masuk</button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-full bg-[#0a0a0a] text-slate-100 overflow-hidden font-inter selection:bg-purple-500/30">
      
      {financeEdit.type && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm bg-[#0f0f0f] border border-white/10 p-8 rounded-[32px] shadow-2xl animate-in zoom-in-95 duration-300">
            <h3 className="text-xl font-black mb-4 uppercase tracking-tight">Edit {financeEdit.type === 'income' ? 'Pemasukan' : 'Pengeluaran'}</h3>
            <input 
              type="number"
              autoFocus
              value={financeEdit.value}
              onChange={(e) => setFinanceEdit({ ...financeEdit, value: e.target.value })}
              className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-6 mb-6 focus:border-orange-500 focus:outline-none"
              placeholder="Masukkan jumlah baru..."
            />
            <div className="flex gap-3">
              <button onClick={() => setFinanceEdit({ type: null, value: '' })} className="flex-1 py-3 bg-white/5 rounded-xl font-bold uppercase text-[10px] tracking-widest">Batal</button>
              <button onClick={handleUpdateFinance} className="flex-1 py-3 bg-orange-600 rounded-xl font-bold uppercase text-[10px] tracking-widest shadow-lg shadow-orange-900/20">Simpan Perubahan</button>
            </div>
          </div>
        </div>
      )}

      <nav className={`w-24 md:w-72 border-r border-white/5 flex flex-col p-6 z-30 shadow-2xl transition-colors duration-500 ${userRole === 'admin' ? 'bg-[#0f0a05]' : 'bg-[#0d0d0d]'}`}>
        <button onClick={() => setShowStats(true)} className="flex items-center gap-3 mb-12 group text-left">
          <div className="w-12 h-12 rounded-2xl overflow-hidden shadow-lg shadow-purple-500/20 group-hover:scale-110 transition-transform">
            {userProfile.avatar ? <img src={userProfile.avatar} className="w-full h-full object-cover" /> : <div className={`w-full h-full flex items-center justify-center bg-gradient-to-tr ${userRole === 'admin' ? 'from-orange-600 to-red-600' : 'from-purple-600 to-indigo-600'}`}><Wind className="text-white w-7 h-7" /></div>}
          </div>
          <div className="hidden md:block"><h1 className="font-outfit font-black text-2xl tracking-tight bg-gradient-to-r from-white to-slate-500 bg-clip-text text-transparent">VAPOR ELITE</h1><p className="text-[10px] text-purple-400 font-bold tracking-widest uppercase">Akun Saya <ChevronRight className="inline w-3 h-3 ml-1" /></p></div>
        </button>
        <div className="space-y-3 flex-1">
          {[
            { id: 'store', label: 'Beranda & Katalog', icon: LayoutGrid, desc: 'Koleksi Utama', role: 'all' },
            { id: 'cart', label: 'Keranjang', icon: ShoppingCart, desc: `${cart.length} Item Tersimpan`, role: 'user' },
            { id: 'payment', label: 'Pembayaran Saya', icon: CreditCard, desc: 'Histori Transaksi', role: 'user' },
            { id: 'support', label: 'Laporan & Feedback', icon: MessageSquareWarning, desc: 'Dukungan Pelanggan', role: 'user' },
            { id: 'admin', label: 'Command Center', icon: ShieldCheck, desc: 'Manajemen & Laporan', role: 'admin' },
            { id: 'payment', label: 'Konfirmasi Bayar', icon: CreditCard, desc: `${transactions.filter(t => t.status === 'Dibayar').length} Perlu Cek`, role: 'admin' },
            { id: 'wallet', label: 'Dompet Elite', icon: Wallet, desc: 'Finansial & Histori', role: 'admin' },
            { id: 'notes', label: 'Catatan Admin', icon: NotebookPen, desc: 'Draft & Ide Bisnis', role: 'admin' },
            { id: 'google-sim', label: 'Google Search', icon: SearchCode, desc: 'Simulasi Indeksasi', role: 'all' },
          ].map((item, idx) => {
            if (item.role === 'admin' && userRole !== 'admin') return null;
            if (item.role === 'user' && userRole !== 'user') return null;
            
            const isActive = mode === item.id;
            
            return (
              <button 
                key={`${item.id}-${idx}`} 
                onClick={() => setMode(item.id as AppMode)} 
                className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all duration-300 group hover:scale-[1.02] active:scale-95 ${isActive ? (userRole === 'admin' ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20 shadow-[0_0_20px_rgba(234,88,12,0.1)]' : 'bg-purple-500/10 text-purple-400 border border-purple-500/20 shadow-[0_0_20px_rgba(147,51,234,0.1)]') : 'hover:bg-white/5 text-slate-500'}`}
              >
                <div className="relative">
                  <item.icon className="w-6 h-6 shrink-0" />
                  {item.id === 'cart' && cart.length > 0 && <span className="absolute -top-2 -right-2 bg-purple-600 text-white text-[8px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-lg animate-bounce">{cart.length}</span>}
                  {item.id === 'payment' && userRole === 'admin' && transactions.filter(t => t.status === 'Dibayar').length > 0 && <span className="absolute -top-2 -right-2 bg-red-600 text-white text-[8px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-lg">{transactions.filter(t => t.status === 'Dibayar').length}</span>}
                </div>
                <div className="text-left hidden md:block"><p className="text-sm font-bold">{item.label}</p><p className="text-[11px] opacity-40">{item.desc}</p></div>
              </button>
            );
          })}
        </div>
        <button onClick={handleLogout} className="w-full flex items-center gap-4 p-4 rounded-2xl text-red-500 hover:bg-red-500/5 mt-auto"><LogOut className="w-6 h-6" /><div className="text-left hidden md:block text-sm font-bold">Keluar</div></button>
      </nav>

      <main className="flex-1 flex flex-col relative overflow-hidden">
        <header className="h-20 border-b border-white/5 flex items-center justify-between px-8 bg-black/40 backdrop-blur-xl z-20">
          <div className="flex items-center gap-4 flex-1">
            <div className="flex items-center gap-2"><span className="text-xs font-bold text-slate-500 uppercase tracking-widest">{mode}</span><ChevronRight className="w-4 h-4 text-slate-800" /></div>
            <div className="hidden lg:flex items-center gap-3 bg-black/60 border border-white/10 rounded-full py-2 px-6 flex-1 max-xl shadow-inner group transition-all hover:border-purple-500/50">
              <Lock className="w-3.5 h-3.5 text-green-500" />
              <div className="flex items-center text-xs font-medium tracking-tight overflow-hidden">
                <span className="text-slate-600">https://</span>
                <span className="text-slate-200 font-bold">{DOMAIN_NAME}</span>
                <span className="text-slate-600">/{mode}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-full"><div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div><span className="text-[10px] font-black text-green-500 uppercase tracking-widest">Sistem Aktif</span></div>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
          {mode === 'store' && (
            <div className="max-w-7xl mx-auto">
              <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
                <div><h2 className="text-4xl font-outfit font-bold mb-2">Halo, {userProfile.name.split(' ')[0]}</h2><p className="text-slate-500">Jelajahi artisan di <span className="text-purple-400 font-bold">{DOMAIN_NAME}</span></p></div>
                <div className="flex flex-wrap gap-2">
                  {['Semua', 'Device', 'Freebase', 'Saltnic', 'Tools', 'Atomizer'].map(cat => (<button key={cat} onClick={() => setFilter(cat)} className={`px-4 py-2 text-[11px] font-black uppercase tracking-wider rounded-lg border transition-all ${filter === cat ? 'bg-white text-black border-white' : 'border-white/10 text-slate-400'}`}>{cat}</button>))}
                </div>
              </div>
              <div className="mb-10 relative group max-w-2xl">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-purple-500 transition-colors" />
                <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Cari produk artisan favorit Anda..." className="w-full bg-[#0f0f0f] border border-white/5 rounded-2xl py-4 pl-14 pr-6 text-sm focus:outline-none focus:border-purple-500/50 shadow-xl" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredProducts.map((product) => (
                  <div key={product.id} onClick={() => setSelectedProduct(product)} className="group cursor-pointer bg-[#0f0f0f] border border-white/5 rounded-3xl overflow-hidden hover:border-purple-500/40 transition-all duration-500 shadow-xl relative">
                    {product.stock <= 0 && <div className="absolute top-4 left-4 z-10 bg-red-600 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">Habis</div>}
                    <div className="aspect-[4/3] relative overflow-hidden"><img src={product.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" /><div className="absolute top-4 right-4 px-3 py-1 bg-black/60 backdrop-blur-md rounded-full text-[10px] font-bold text-purple-400 border border-purple-500/20">{product.category}</div></div>
                    <div className="p-6">
                      <div className="flex justify-between items-start mb-2"><h3 className="text-xl font-bold">{product.name}</h3><span className="text-purple-400 font-bold">{product.price}</span></div>
                      <p className="text-slate-500 text-sm mb-6 line-clamp-1">{product.description}</p>
                      <div className="flex items-center justify-between"><div className="flex items-center gap-1"><Star className="w-4 h-4 text-yellow-500 fill-yellow-500" /><span className="text-sm font-bold">{product.rating}</span></div><div className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">{product.totalSold.toLocaleString()} Terjual</div></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {mode === 'cart' && (
            <div className="max-w-4xl mx-auto flex flex-col min-h-full">
              <h2 className="text-4xl font-outfit font-black mb-8">Keranjang Anda</h2>
              {cart.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center opacity-40"><ShoppingCart className="w-16 h-16 mb-6" /><h3 className="text-xl font-bold">Keranjang Kosong</h3></div>
              ) : (
                <div className="space-y-6 pb-20">
                  <div className="bg-[#0f0f0f] border border-white/5 rounded-[32px] overflow-hidden">
                    {cart.map((item) => (
                      <div key={item.product.id} className="flex items-center gap-6 p-6 border-b border-white/5 last:border-none group">
                        <img src={item.product.image} className="w-20 h-20 rounded-2xl object-cover" />
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <div><h4 className="font-bold">{item.product.name}</h4><p className="text-xs text-purple-400 font-bold uppercase">{item.product.category}</p></div>
                            <p className="font-black">{item.product.price}</p>
                          </div>
                          <div className="flex items-center justify-between mt-4">
                            <div className="flex items-center bg-white/5 rounded-xl border border-white/5 p-1">
                              <button onClick={() => updateCartQuantity(item.product.id, -1)} className="p-2 hover:bg-white/10 rounded-lg"><Minus className="w-4 h-4" /></button>
                              <span className="w-10 text-center font-bold text-sm">{item.quantity}</span>
                              <button onClick={() => updateCartQuantity(item.product.id, 1)} className="p-2 hover:bg-white/10 rounded-lg"><Plus className="w-4 h-4" /></button>
                            </div>
                            <button onClick={() => removeFromCart(item.product.id)} className="p-2 text-red-500 hover:bg-red-500/10 rounded-xl transition-all opacity-0 group-hover:opacity-100"><Trash2 className="w-5 h-5" /></button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="bg-[#0f0f0f] border border-white/10 rounded-[32px] p-8 shadow-2xl">
                    <div className="flex justify-between items-center mb-6"><p className="text-slate-500 font-bold uppercase text-xs">Total Pembayaran</p><p className="text-3xl font-black text-purple-400">Rp {calculateTotal().toLocaleString('id-ID')}</p></div>
                    <button onClick={initiatePayment} className="w-full py-5 bg-white text-black rounded-2xl font-black text-xs uppercase tracking-[0.4em] hover:bg-purple-600 hover:text-white transition-all shadow-xl">Proses Pembayaran</button>
                  </div>
                </div>
              )}
            </div>
          )}

          {mode === 'payment' && userRole === 'user' && (
            <div className="max-w-4xl mx-auto py-12 animate-in fade-in slide-in-from-bottom-8 duration-500">
               <div className="flex items-center justify-between mb-12">
                   <div>
                        <h2 className="text-4xl font-outfit font-black mb-2">Pilih Pembayaran</h2>
                        <p className="text-slate-500 uppercase tracking-widest text-[10px] font-black">Elite Transaction Secure Portal</p>
                   </div>
                   <div className="flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 rounded-xl">
                        <Lock className="w-4 h-4 text-green-500" />
                        <span className="text-[10px] font-black uppercase text-slate-400">SSL Encrypted</span>
                   </div>
               </div>

               <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                   <div className="space-y-6">
                        <div className="bg-[#0f0f0f] border border-white/5 rounded-[40px] p-10 shadow-2xl">
                            <h3 className="text-xl font-bold mb-8 flex items-center gap-3">
                                <ReceiptText className="w-6 h-6 text-purple-400" /> Ringkasan Order
                            </h3>
                            <div className="space-y-4 mb-8">
                                {cart.length > 0 ? cart.map(item => (
                                    <div key={item.product.id} className="flex justify-between items-center py-2 border-b border-white/[0.03]">
                                        <div className="text-sm font-medium text-slate-300">{item.product.name} <span className="text-[10px] text-slate-600">x{item.quantity}</span></div>
                                        <div className="text-sm font-black text-white">{item.product.price}</div>
                                    </div>
                                )) : (
                                    <p className="text-xs text-slate-600 uppercase font-bold tracking-widest">Tidak ada item aktif.</p>
                                )}
                            </div>
                            <div className="flex justify-between items-center pt-4">
                                <span className="text-xs font-black uppercase text-slate-500 tracking-widest">Total Bayar</span>
                                <span className="text-3xl font-black text-purple-400">Rp {calculateTotal().toLocaleString('id-ID')}</span>
                            </div>
                        </div>

                        <div className="bg-gradient-to-tr from-purple-900/20 to-[#0f0f0f] border border-purple-500/20 rounded-[40px] p-8">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 bg-purple-500/10 rounded-2xl flex items-center justify-center text-purple-400"><QrCode className="w-6 h-6" /></div>
                                <p className="text-xs font-bold text-slate-400 leading-relaxed">Pilih metode pembayaran dan lakukan transfer sesuai nominal. Admin akan memverifikasi bukti transaksi dalam hitungan menit.</p>
                            </div>
                        </div>
                   </div>

                   <div className="space-y-4">
                       <h3 className="text-xs font-black uppercase text-slate-600 tracking-widest ml-4 mb-2">Metode Tersedia</h3>
                       {[
                           { id: 'qris', name: 'QRIS Auto-Check', icon: QrCode, desc: 'Scan & Bayar Instan' },
                           { id: 'va', name: 'Virtual Account Elite', icon: Banknote, desc: 'BCA, Mandiri, BNI' },
                           { id: 'wallet', name: 'Elite Digital Wallet', icon: Wallet, desc: 'OVO, Dana, LinkAja' },
                           { id: 'card', name: 'Credit / Debit Card', icon: CreditCard, desc: 'Visa, Mastercard' }
                       ].map(method => (
                           <button 
                             key={method.id}
                             onClick={() => handleProcessPayment(method.name)}
                             className="w-full p-6 bg-[#0f0f0f] border border-white/5 rounded-3xl flex items-center gap-6 hover:border-purple-500/40 hover:scale-[1.02] transition-all group"
                           >
                               <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center text-slate-400 group-hover:bg-purple-600 group-hover:text-white transition-all">
                                   <method.icon className="w-7 h-7" />
                               </div>
                               <div className="text-left">
                                   <p className="font-bold text-lg">{method.name}</p>
                                   <p className="text-xs text-slate-500">{method.desc}</p>
                               </div>
                               <ChevronRight className="ml-auto w-5 h-5 text-slate-700 group-hover:text-purple-400" />
                           </button>
                       ))}
                   </div>
               </div>
            </div>
          )}

          {mode === 'payment' && userRole === 'admin' && (
            <div className="max-w-7xl mx-auto space-y-12 animate-in fade-in duration-700">
                <div className="flex items-center justify-between">
                    <div>
                        <h2 className="text-4xl font-outfit font-black tracking-tight mb-2">Konfirmasi Pembayaran</h2>
                        <p className="text-slate-500">Verifikasi bukti transfer pelanggan untuk memproses pesanan.</p>
                    </div>
                    <div className="px-6 py-3 bg-red-600/10 border border-red-600/20 rounded-2xl text-red-500 flex items-center gap-3">
                        <AlertCircle className="w-5 h-5" />
                        <span className="text-[10px] font-black uppercase tracking-widest">{transactions.filter(t => t.status === 'Dibayar').length} Menunggu</span>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {transactions.filter(t => t.status === 'Dibayar').map(tx => (
                        <div key={tx.id} className={`group bg-[#0f0f0f] border border-white/5 p-8 rounded-[40px] shadow-2xl relative overflow-hidden transition-all ${confirmingTransactionId === tx.id ? 'scale-95 blur-sm brightness-50' : 'hover:border-orange-500/20'}`}>
                            <div className="flex justify-between items-start mb-8">
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 bg-orange-600/10 rounded-2xl flex items-center justify-center text-orange-500"><Banknote className="w-6 h-6" /></div>
                                    <div>
                                        <p className="text-[10px] font-black uppercase text-slate-600">{tx.id}</p>
                                        <h4 className="font-black text-xl">{tx.userName}</h4>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-1">{tx.date}</p>
                                    <span className="px-3 py-1 bg-yellow-500/10 text-yellow-500 rounded-full text-[9px] font-black uppercase border border-yellow-500/20">UNCONFIRMED</span>
                                </div>
                            </div>

                            <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-6 mb-8">
                                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-4">Item Transaksi</p>
                                <div className="space-y-3">
                                    {tx.items.map((item, idx) => (
                                        <div key={idx} className="flex justify-between items-center">
                                            <span className="text-sm font-medium text-slate-300">{item.name} <span className="text-slate-600 text-[10px]">x{item.qty}</span></span>
                                            <span className="text-sm font-bold text-white">{item.price}</span>
                                        </div>
                                    ))}
                                </div>
                                <div className="mt-6 pt-6 border-t border-white/5 flex justify-between items-center">
                                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-600">Metode: {tx.paymentMethod}</span>
                                    <span className="text-2xl font-black text-orange-500">Rp {tx.totalPrice.toLocaleString('id-ID')}</span>
                                </div>
                            </div>

                            <div className="flex gap-3">
                                <button className="flex-1 py-4 bg-white/5 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-red-500/10 hover:text-red-500 transition-all">Batalkan</button>
                                <button 
                                  onClick={() => handleConfirmTransaction(tx.id)}
                                  className="flex-[2] py-4 bg-white text-black rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] shadow-xl hover:bg-orange-600 hover:text-white transition-all flex items-center justify-center gap-3 active:scale-95"
                                >
                                    <PackageCheck className="w-4 h-4" /> Konfirmasi & Kurangi Stok
                                </button>
                            </div>
                        </div>
                    ))}
                    
                    {transactions.filter(t => t.status === 'Dibayar').length === 0 && (
                        <div className="col-span-2 py-32 flex flex-col items-center justify-center opacity-30 text-center">
                            <CheckCircle2 className="w-16 h-16 mb-6 text-green-500" />
                            <h3 className="text-2xl font-black font-outfit uppercase tracking-tighter">Zero Pending Transactions</h3>
                            <p className="text-sm">Semua pembayaran pelanggan telah terverifikasi sistem.</p>
                        </div>
                    )}
                </div>
            </div>
          )}

          {mode === 'wallet' && userRole === 'admin' && (
            <div className="max-w-7xl mx-auto space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-4xl font-outfit font-black tracking-tight mb-2">Dompet Elite</h2>
                  <p className="text-slate-500">Monitor arus kas dan histori transaksi global.</p>
                </div>
                <div className="flex items-center gap-4 bg-[#0f0f0f] p-2 rounded-2xl border border-white/5">
                  <div className="px-6 py-3 bg-orange-600/10 text-orange-500 rounded-xl border border-orange-500/20 flex items-center gap-3">
                    <Coins className="w-5 h-5" />
                    <span className="font-black text-xs uppercase tracking-widest">Saldo Real-time</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div key={finances.income} className="group bg-[#0f0f0f] border border-white/10 p-10 rounded-[40px] shadow-2xl relative overflow-hidden transition-all hover:border-green-500/30 finance-card-anim">
                  <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-110 transition-transform"><ArrowUpRight className="w-40 h-40 text-green-500" /></div>
                  <div className="flex justify-between items-start mb-6">
                    <div className="w-16 h-16 bg-green-500/10 rounded-3xl flex items-center justify-center text-green-500"><TrendingUp className="w-8 h-8" /></div>
                    <button onClick={() => setFinanceEdit({ type: 'income', value: finances.income.toString() })} className="p-2 hover:bg-white/5 rounded-xl text-slate-500 transition-all opacity-0 group-hover:opacity-100"><Edit2 className="w-4 h-4" /></button>
                  </div>
                  <p className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-600 mb-2">Total Pemasukan</p>
                  <p className="text-3xl font-black text-green-500">Rp {finances.income.toLocaleString('id-ID')}</p>
                </div>

                <div key={finances.expenses} className="group bg-[#0f0f0f] border border-white/10 p-10 rounded-[40px] shadow-2xl relative overflow-hidden transition-all hover:border-red-500/30 finance-card-anim">
                  <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-110 transition-transform"><ArrowDownRight className="w-40 h-40 text-red-500" /></div>
                  <div className="flex justify-between items-start mb-6">
                    <div className="w-16 h-16 bg-red-500/10 rounded-3xl flex items-center justify-center text-red-500"><TrendingDown className="w-8 h-8" /></div>
                    <button onClick={() => setFinanceEdit({ type: 'expenses', value: finances.expenses.toString() })} className="p-2 hover:bg-white/5 rounded-xl text-slate-500 transition-all opacity-0 group-hover:opacity-100"><Edit2 className="w-4 h-4" /></button>
                  </div>
                  <p className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-600 mb-2">Total Pengeluaran</p>
                  <p className="text-3xl font-black text-red-500">Rp {finances.expenses.toLocaleString('id-ID')}</p>
                </div>

                <div key={totalSaldo} className="group bg-[#0f0f0f] border border-white/10 p-10 rounded-[40px] shadow-2xl relative overflow-hidden transition-all hover:border-purple-500/30 finance-card-anim">
                  <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-110 transition-transform"><Banknote className="w-40 h-40 text-purple-500" /></div>
                  <div className="flex justify-between items-start mb-6">
                    <div className="w-16 h-16 bg-purple-500/10 rounded-3xl flex items-center justify-center text-purple-500"><Wallet className="w-8 h-8" /></div>
                  </div>
                  <p className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-600 mb-2">Total Saldo (Profit)</p>
                  <p className={`text-3xl font-black ${totalSaldo >= 0 ? 'text-purple-400' : 'text-orange-500'}`}>Rp {totalSaldo.toLocaleString('id-ID')}</p>
                </div>
              </div>

              <div className="bg-[#0f0f0f] border border-white/5 rounded-[40px] shadow-2xl overflow-hidden">
                <div className="p-8 border-b border-white/5 flex items-center justify-between bg-white/[0.01]">
                  <div className="flex items-center gap-4">
                    <History className="w-5 h-5 text-orange-500" />
                    <h3 className="text-xl font-bold font-outfit">Riwayat Transaksi Umum</h3>
                  </div>
                  <button className="px-6 py-2 bg-white/5 rounded-xl text-[10px] font-black uppercase tracking-widest border border-white/10 hover:bg-white/10 transition-all">Export CSV</button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-white/5 bg-white/[0.01]">
                        <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-slate-500">ID TRX</th>
                        <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-slate-500">Customer</th>
                        <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-slate-500">Status</th>
                        <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-slate-500">Items</th>
                        <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-slate-500 text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {transactions.filter(t => t.status === 'Selesai').length === 0 ? (
                        <tr><td colSpan={5} className="px-8 py-20 text-center text-slate-600 font-bold uppercase text-[10px] tracking-widest">Belum ada transaksi terekam</td></tr>
                      ) : (
                        transactions.filter(t => t.status === 'Selesai').map(record => (
                          <tr key={record.id} className="hover:bg-white/[0.02] transition-colors group">
                            <td className="px-8 py-6 text-sm font-black text-orange-500">{record.id}</td>
                            <td className="px-8 py-6">
                              <p className="text-sm font-bold text-white mb-1">{record.userName}</p>
                              <p className="text-[10px] text-slate-500">{record.userEmail}</p>
                            </td>
                            <td className="px-8 py-6">
                               <span className="px-2 py-0.5 bg-green-500/10 text-green-500 rounded-full text-[8px] font-black uppercase border border-green-500/20">CONFIRMED</span>
                            </td>
                            <td className="px-8 py-6">
                              {record.items.map((item, idx) => (
                                <p key={idx} className="text-xs text-slate-400 mb-1 leading-tight">• {item.name} <span className="text-[10px] font-bold text-slate-600">({item.qty}x)</span></p>
                              ))}
                            </td>
                            <td className="px-8 py-6 text-right font-black text-green-500">Rp {record.totalPrice.toLocaleString('id-ID')}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {mode === 'notes' && userRole === 'admin' && (
            <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-10 animate-in fade-in slide-in-from-bottom-6 duration-700">
              <div className="lg:col-span-1 space-y-6">
                <div className="mb-8">
                  <h2 className="text-4xl font-outfit font-black tracking-tight mb-2">Elite Notes</h2>
                  <p className="text-slate-500">Catat ide, strategi, dan draft operasional.</p>
                </div>
                <div className="bg-[#0f0f0f] border border-white/10 p-8 rounded-[32px] shadow-2xl">
                  <form onSubmit={handleSaveNote} className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Judul Catatan</label>
                      <input 
                        required 
                        value={noteForm.title} 
                        onChange={(e) => setNoteForm({ ...noteForm, title: e.target.value })}
                        className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-5 text-sm focus:border-orange-500 focus:outline-none" 
                        placeholder="Input judul..."
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Konten</label>
                      <textarea 
                        required 
                        rows={6}
                        value={noteForm.content} 
                        onChange={(e) => setNoteForm({ ...noteForm, content: e.target.value })}
                        className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-5 text-sm focus:border-orange-500 focus:outline-none resize-none" 
                        placeholder="Tulis ide brilian Anda di sini..."
                      />
                    </div>
                    <button type="submit" className="w-full py-5 bg-white text-black rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-orange-600 hover:text-white transition-all shadow-xl active:scale-95 flex items-center justify-center gap-3">
                      <Plus className="w-4 h-4" /> Simpan Draft
                    </button>
                  </form>
                </div>
              </div>
              <div className="lg:col-span-2">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {adminNotes.map(note => (
                    <div key={note.id} className="group bg-[#0f0f0f] border border-white/5 p-8 rounded-[32px] shadow-xl hover:border-orange-500/20 transition-all flex flex-col">
                      <div className="flex justify-between items-start mb-4">
                        <div className="w-10 h-10 bg-orange-600/10 rounded-xl flex items-center justify-center text-orange-500"><NotebookPen className="w-5 h-5" /></div>
                        <p className="text-[9px] font-black text-slate-700 uppercase">{note.date}</p>
                      </div>
                      <h4 className="text-xl font-bold mb-3 group-hover:text-orange-400 transition-colors">{note.title}</h4>
                      <p className="text-sm text-slate-500 leading-relaxed flex-1">{note.content}</p>
                      <div className="flex gap-2 mt-6 opacity-0 group-hover:opacity-100 transition-all">
                        <button onClick={() => setAdminNotes(prev => prev.filter(n => n.id !== note.id))} className="flex-1 py-2 bg-red-500/10 text-red-500 rounded-lg text-[10px] font-black uppercase hover:bg-red-500 hover:text-white transition-all">Hapus</button>
                        <button className="flex-1 py-2 bg-white/5 text-slate-400 rounded-lg text-[10px] font-black uppercase hover:bg-white/10 transition-all">Edit</button>
                      </div>
                    </div>
                  ))}
                  {adminNotes.length === 0 && (
                    <div className="col-span-2 flex flex-col items-center justify-center py-20 opacity-20"><NotebookPen className="w-16 h-16 mb-4" /><p className="font-bold uppercase tracking-widest text-xs">Belum ada catatan bisnis</p></div>
                  )}
                </div>
              </div>
            </div>
          )}

          {mode === 'admin' && userRole === 'admin' && (
            <div className="max-w-7xl mx-auto space-y-12 animate-in fade-in duration-700">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                  <h2 className="text-4xl font-outfit font-black tracking-tight mb-2">Command Center</h2>
                  <p className="text-slate-500">Sistem manajemen inventaris dan dukungan terpadu.</p>
                </div>
                <div className="flex bg-white/5 p-1 rounded-[24px] border border-white/10 overflow-hidden shadow-2xl">
                  {[
                    { id: 'inventory', label: 'Stok Produk', icon: Package },
                    { id: 'reports', label: 'Inbox Laporan', icon: MessageSquareWarning },
                    { id: 'soldout', label: 'History Sold Out', icon: X },
                  ].map((tab) => (
                    <button 
                      key={tab.id}
                      onClick={() => {
                        const el = document.getElementById('admin-content');
                        el?.classList.add('opacity-0');
                        setTimeout(() => {
                          setAdminTab(tab.id as AdminTab);
                          el?.classList.remove('opacity-0');
                        }, 200);
                      }}
                      className={`flex items-center gap-2 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${adminTab === tab.id ? 'bg-orange-600 text-white shadow-xl' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}
                    >
                      <tab.icon className="w-4 h-4" /> {tab.label}
                    </button>
                  ))}
                </div>
              </div>

              <div id="admin-content" className="transition-all duration-300">
                {adminTab === 'inventory' && (
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-1">
                      <div id="admin-form" className={`bg-[#0f0f0f] border rounded-[32px] p-8 sticky top-0 transition-all ${editingProductId ? 'border-purple-500 shadow-[0_0_50px_rgba(168,85,247,0.2)]' : 'border-orange-500/20 shadow-xl'}`}>
                        <div className="flex items-center justify-between mb-8">
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${editingProductId ? 'bg-purple-500/10 text-purple-500' : 'bg-orange-500/10 text-orange-500'}`}>{editingProductId ? <Edit2 className="w-6 h-6" /> : <Plus className="w-6 h-6" />}</div>
                            <h3 className="text-xl font-bold font-outfit">{editingProductId ? 'Edit Produk' : 'Tambah Produk'}</h3>
                          </div>
                        </div>
                        <form onSubmit={handleAddProduct} className="space-y-4">
                          <input required value={newProduct.name} onChange={e => setNewProduct({...newProduct, name: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm" placeholder="Nama Produk" />
                          <div className="grid grid-cols-2 gap-3">
                            <select value={newProduct.category} onChange={e => setNewProduct({...newProduct, category: e.target.value as any})} className="bg-[#1a1a1a] border border-white/10 rounded-xl py-3 px-4 text-sm"><option value="Device">Device</option><option value="Freebase">Freebase</option><option value="Saltnic">Saltnic</option><option value="Tools">Tools</option><option value="Atomizer">Atomizer</option></select>
                            <input required value={newProduct.price} onChange={e => setNewProduct({...newProduct, price: e.target.value})} className="bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm" placeholder="Rp 0" />
                          </div>
                          <div className="grid grid-cols-3 gap-3">
                            <input type="number" step="0.1" required value={newProduct.rating} onChange={e => setNewProduct({...newProduct, rating: parseFloat(e.target.value)})} className="bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm" placeholder="Rating" />
                            <input type="number" required value={newProduct.totalSold} onChange={e => setNewProduct({...newProduct, totalSold: parseInt(e.target.value)})} className="bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm" placeholder="Sold" />
                            <input type="number" required value={newProduct.stock} onChange={e => setNewProduct({...newProduct, stock: parseInt(e.target.value)})} className="bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm" placeholder="Stok" />
                          </div>
                          <div onClick={() => productImageInputRef.current?.click()} className="aspect-video rounded-xl border-2 border-dashed border-white/10 bg-white/5 flex flex-col items-center justify-center cursor-pointer hover:border-orange-500 overflow-hidden relative group">
                            {newProduct.image ? <img src={newProduct.image} className="w-full h-full object-cover" /> : <p className="text-[10px] font-bold text-slate-500 uppercase">Upload Gambar</p>}
                          </div>
                          <input type="file" ref={productImageInputRef} className="hidden" accept="image/*" onChange={handleProductImageChange} />
                          <textarea required value={newProduct.description} onChange={e => setNewProduct({...newProduct, description: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm h-24 resize-none" placeholder="Deskripsi..." />
                          <div className="flex gap-2">
                            {editingProductId && <button type="button" onClick={() => { setEditingProductId(null); setNewProduct({ name: '', category: 'Device', price: '', description: '', image: '', rating: 5.0, totalSold: 0, stock: 0 }); }} className="flex-1 py-4 bg-white/5 rounded-2xl text-[10px] font-black uppercase tracking-widest">Batal</button>}
                            <button type="submit" className="flex-[2] py-4 bg-orange-600 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-orange-700 transition-all shadow-lg active:scale-95">Simpan Produk</button>
                          </div>
                        </form>
                      </div>
                    </div>
                    <div className="lg:col-span-2 space-y-6">
                      <div className="bg-[#0f0f0f] border border-white/5 rounded-[32px] p-8">
                        <h3 className="text-xl font-bold mb-8">Tabel Inventaris</h3>
                        <div className="space-y-4">
                          {inventory.map(p => (
                            <div key={p.id} className="group flex items-center gap-4 p-4 bg-white/5 border border-white/5 rounded-2xl transition-all hover:border-orange-500/30">
                              <img src={p.image} className="w-16 h-16 rounded-xl object-cover" />
                              <div className="flex-1 overflow-hidden">
                                <h4 className="font-bold text-sm truncate">{p.name}</h4>
                                <p className="text-[11px] text-slate-500 mt-1 uppercase tracking-widest font-black">{p.category} • {p.price}</p>
                              </div>
                              <div className="text-right">
                                <p className={`text-[10px] font-black uppercase mb-1 ${p.stock <= 5 ? 'text-red-500' : 'text-slate-500'}`}>Stok: {p.stock}</p>
                                <div className="flex items-center gap-2">
                                  <button onClick={() => handleEditProduct(p)} className="p-2 text-blue-400 hover:bg-blue-400/10 rounded-lg"><Edit2 className="w-4 h-4" /></button>
                                  <button onClick={() => handleDeleteProduct(p.id)} className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {adminTab === 'reports' && (
                  <div className="bg-[#0f0f0f] border border-white/5 rounded-[32px] overflow-hidden shadow-2xl">
                    <div className="divide-y divide-white/5">
                      {reports.map((report) => (
                        <div key={report.id} className="p-8 hover:bg-white/[0.02] transition-all">
                          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                            <div className="flex items-start gap-6 flex-1">
                              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${report.priority === 'Tinggi' ? 'bg-red-500/10 text-red-500' : 'bg-blue-500/10 text-blue-500'}`}><MessageSquareWarning className="w-6 h-6" /></div>
                              <div>
                                <div className="flex items-center gap-3 mb-1"><span className="text-[10px] font-black text-slate-600">{report.id}</span><span className="px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest bg-red-600 text-white">{report.status}</span></div>
                                <h3 className="text-xl font-bold mb-1">{report.subject}</h3>
                                <p className="text-sm text-slate-500 leading-relaxed max-w-2xl">{report.message}</p>
                                <div className="flex items-center gap-4 mt-4 text-[10px] font-bold text-slate-600 uppercase"><span><User className="inline w-3 h-3 mr-1" />{report.userName}</span><span><Mail className="inline w-3 h-3 mr-1" />{report.userEmail}</span></div>
                              </div>
                            </div>
                            {report.status !== 'Selesai' && (
                              <div className="flex gap-2">
                                <button onClick={() => handleUpdateReportStatus(report.id, 'Diproses')} className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-[10px] font-black uppercase">Diproses</button>
                                <button onClick={() => handleUpdateReportStatus(report.id, 'Selesai')} className="px-4 py-2 bg-green-600 text-white rounded-xl text-[10px] font-black uppercase">Selesai</button>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {adminTab === 'soldout' && (
                  <div className="bg-[#0f0f0f] border border-white/5 rounded-[40px] shadow-2xl overflow-hidden p-8 animate-in zoom-in-95 duration-500">
                    <div className="flex items-center gap-4 mb-10">
                      <div className="w-14 h-14 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-500"><AlertCircle className="w-8 h-8" /></div>
                      <div><h3 className="text-2xl font-outfit font-black tracking-tight">Katalog Sold Out</h3><p className="text-slate-500">Monitor produk yang stoknya habis dan lakukan restok cepat.</p></div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {inventory.filter(p => p.stock === 0).length === 0 ? (
                        <div className="col-span-3 py-20 text-center opacity-30"><CheckCircle2 className="w-16 h-16 mx-auto mb-4" /><p className="font-bold uppercase tracking-[0.3em] text-[10px]">Semua stok tersedia</p></div>
                      ) : (
                        inventory.filter(p => p.stock === 0).map(p => (
                          <div key={p.id} className={`group bg-black/40 border border-red-500/20 p-6 rounded-[32px] transition-all relative overflow-hidden hover:border-red-500/40 ${restockingId === p.id ? 'scale-95 blur-sm' : 'scale-100'}`}>
                            <div className="flex gap-4 mb-6">
                              <img src={p.image} className="w-20 h-20 rounded-2xl object-cover grayscale" />
                              <div className="flex-1">
                                <h4 className="font-bold text-lg leading-tight mb-1">{p.name}</h4>
                                <p className="text-[10px] font-black text-red-500 uppercase tracking-widest">STOCK: EMPTY</p>
                              </div>
                            </div>
                            <button 
                              onClick={() => handleRestock(p.id)}
                              disabled={restockingId === p.id}
                              className={`w-full py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all active:scale-95 shadow-lg flex items-center justify-center gap-2 ${restockingId === p.id ? 'bg-slate-800 text-slate-500' : 'bg-white text-black hover:bg-orange-600 hover:text-white'}`}
                            >
                              {restockingId === p.id ? <Zap className="w-4 h-4 animate-spin" /> : <Package className="w-4 h-4" />} Restock Now (+10)
                            </button>
                            {restockingId === p.id && <div className="absolute inset-0 bg-orange-600/10 flex items-center justify-center animate-pulse"><Zap className="w-10 h-10 text-orange-500 animate-bounce" /></div>}
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {mode === 'payment' && userRole === 'admin' && (
              /* Handled in admin block above */
              null
          )}

          {mode === 'support' && userRole === 'user' && (
            <div className="max-w-2xl mx-auto py-12">
              <div className="text-center mb-12"><div className="w-20 h-20 bg-purple-600/10 rounded-[32px] flex items-center justify-center mx-auto mb-6 text-purple-500"><MessageSquareWarning className="w-10 h-10" /></div><h2 className="text-4xl font-outfit font-black tracking-tight mb-2">Feedback & Laporan</h2><p className="text-slate-500">Punya kendala atau saran? Kami siap membantu.</p></div>
              <div className="bg-[#0f0f0f] border border-white/10 rounded-[40px] p-8 shadow-2xl">
                <form onSubmit={handleSubmitReport} className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <select value={reportForm.type} onChange={(e) => setReportForm({...reportForm, type: e.target.value as any})} className="bg-white/5 border border-white/10 rounded-2xl py-4 px-5 text-sm focus:border-purple-500 outline-none"><option value="Kendala Teknis">Kendala Teknis</option><option value="Saran Produk">Saran Produk</option><option value="Masalah Pembayaran">Masalah Pembayaran</option><option value="Lainnya">Lainnya</option></select>
                    <select value={reportForm.priority} onChange={(e) => setReportForm({...reportForm, priority: e.target.value as any})} className="bg-white/5 border border-white/10 rounded-2xl py-4 px-5 text-sm focus:border-purple-500 outline-none"><option value="Rendah">Rendah</option><option value="Sedang">Sedang</option><option value="Tinggi">Tinggi</option></select>
                  </div>
                  <input required placeholder="Subjek Masalah" value={reportForm.subject} onChange={(e) => setReportForm({...reportForm, subject: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-5 text-sm outline-none" />
                  <textarea required rows={5} placeholder="Pesan Detail..." value={reportForm.message} onChange={(e) => setReportForm({...reportForm, message: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-5 text-sm outline-none resize-none" />
                  <button type="submit" className="w-full py-5 bg-white text-black rounded-2xl font-black text-xs uppercase tracking-[0.3em] hover:bg-purple-600 hover:text-white transition-all shadow-xl"><Send className="inline w-4 h-4 mr-2" /> Kirim Laporan</button>
                </form>
              </div>
            </div>
          )}
          
          {mode === 'google-sim' && (
            <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-2xl overflow-hidden min-h-[80vh] flex flex-col">
              <div className="p-6 border-b border-slate-100 bg-slate-50 flex items-center gap-8">
                <div className="flex items-center gap-1"><div className="w-3 h-3 rounded-full bg-blue-500"></div><div className="w-3 h-3 rounded-full bg-red-500"></div><div className="w-3 h-3 rounded-full bg-yellow-500"></div><div className="w-3 h-3 rounded-full bg-green-500"></div></div>
                <div className="flex-1 bg-white border border-slate-200 rounded-full py-2.5 px-6 flex items-center gap-4 shadow-sm">
                  <Search className="w-4 h-4 text-slate-400" />
                  <span className="text-sm text-slate-800 font-medium">vape store elite artisan</span>
                  <div className="ml-auto flex items-center gap-3"><Mic className="w-4 h-4 text-blue-500" /><Camera className="w-4 h-4 text-blue-500" /></div>
                </div>
              </div>
              <div className="flex-1 p-8 sm:p-12 space-y-12">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-[12px] text-slate-500 mb-1"><div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center"><Globe className="w-3 h-3" /></div><span>https://{DOMAIN_NAME}</span><span>› product › artisan</span></div>
                  <h3 onClick={() => setMode('store')} className="text-xl text-blue-700 font-medium hover:underline cursor-pointer">Vapor Elite | Vaping Artisan & Konsultan AI Profesional</h3>
                  <p className="text-sm text-slate-600 leading-relaxed max-w-2xl">Akses koleksi artisan terbaik dari {DOMAIN_NAME}. Liquid premium, mod high-end, dan konsultan AI siap melayani Anda.</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {selectedProduct && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-12">
            <div className="absolute inset-0 bg-black/90 backdrop-blur-xl animate-in fade-in" onClick={() => setSelectedProduct(null)}></div>
            <div className="w-full max-w-4xl bg-[#0f0f0f] border border-white/10 rounded-[40px] shadow-2xl relative z-10 overflow-hidden flex animate-in zoom-in-95">
              <div className="w-1/2 relative"><img src={selectedProduct.image} className="w-full h-full object-cover" /></div>
              <div className="flex-1 p-12 flex flex-col">
                <button onClick={() => setSelectedProduct(null)} className="absolute top-8 right-8 p-2 rounded-full hover:bg-white/5 text-slate-400"><X className="w-6 h-6" /></button>
                <div className="flex items-center gap-2 mb-2"><span className="px-3 py-1 bg-purple-500/10 text-purple-400 rounded-full text-[10px] font-black uppercase tracking-widest border border-purple-500/20">{selectedProduct.category}</span><div className="flex items-center gap-1 ml-auto"><Star className="w-4 h-4 text-yellow-500 fill-yellow-500" /><span className="text-sm font-bold">{selectedProduct.rating}</span></div></div>
                <h2 className="text-4xl font-outfit font-black tracking-tight mb-2">{selectedProduct.name}</h2>
                <p className="text-purple-400 text-3xl font-black mb-8">{selectedProduct.price}</p>
                <div className="flex gap-4 mb-8">
                  <div className="flex-1 p-4 bg-white/5 rounded-2xl border border-white/5"><p className="text-[10px] font-black uppercase text-slate-500 mb-1">Terjual</p><p className="text-xl font-bold">{selectedProduct.totalSold.toLocaleString()}</p></div>
                  <div className={`flex-1 p-4 rounded-2xl border ${selectedProduct.stock > 0 ? 'bg-white/5 border-white/5' : 'bg-red-500/10 border-red-500/20'}`}><p className="text-[10px] font-black uppercase text-slate-500 mb-1">Stok</p><p className="text-xl font-bold">{selectedProduct.stock > 0 ? selectedProduct.stock : 'Habis'}</p></div>
                </div>
                <p className="text-slate-400 text-sm leading-relaxed mb-12 flex-1">{selectedProduct.description}</p>
                <button onClick={() => handleAddToCart(selectedProduct)} disabled={selectedProduct.stock <= 0} className={`w-full py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl transition-all active:scale-95 ${selectedProduct.stock > 0 ? 'bg-white text-black hover:bg-purple-600 hover:text-white' : 'bg-slate-800 text-slate-500 cursor-not-allowed'}`}>{selectedProduct.stock > 0 ? 'Tambahkan ke Keranjang' : 'Stok Kosong'}</button>
              </div>
            </div>
          </div>
        )}

        {statusMessage && (<div className="fixed bottom-10 right-10 z-[100] animate-in slide-in-from-right"><div className={`px-6 py-4 rounded-2xl shadow-2xl border flex items-center gap-3 ${userRole === 'admin' ? 'bg-orange-600' : 'bg-purple-600'}`}><Check className="w-5 h-5" /><p className="text-xs font-bold uppercase tracking-widest">{statusMessage}</p></div></div>)}
      </main>
      <style>{`
        .glass-panel { background: rgba(15, 15, 15, 0.7); backdrop-filter: blur(20px); } 
        .custom-scrollbar::-webkit-scrollbar { width: 4px; } 
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; } 
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.05); border-radius: 10px; }
        
        .finance-card-anim {
          animation: finance-update 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        
        @keyframes finance-update {
          0% { transform: scale(1); filter: brightness(1); }
          50% { transform: scale(1.03); filter: brightness(1.2); }
          100% { transform: scale(1); filter: brightness(1); }
        }

        @keyframes restock-bounce {
          0% { transform: scale(1); }
          50% { transform: scale(1.1); box-shadow: 0 0 30px rgba(234, 88, 12, 0.5); }
          100% { transform: scale(1); }
        }

        .confirm-anim {
          animation: confirm-pop 1.5s ease-out infinite;
        }

        @keyframes confirm-pop {
           0% { transform: scale(1); opacity: 1; }
           50% { transform: scale(1.05); opacity: 0.8; }
           100% { transform: scale(1); opacity: 1; }
        }
      `}</style>
    </div>
  );
};

const root = createRoot(document.getElementById('root')!);
root.render(<VaporEliteApp />);
